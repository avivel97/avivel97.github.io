param(
    [string]$RepoPath = "C:\Users\Vladimir\Documents\GitHub\avivel97.github.io"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$indexPath = Join-Path $RepoPath "index.html"
$i18nPath = Join-Path $RepoPath "i18n.js"

foreach ($path in @($indexPath, $i18nPath)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Required file not found: $path"
    }
}

function Replace-Exact {
    param(
        [Parameter(Mandatory = $true)][string]$Text,
        [Parameter(Mandatory = $true)][string]$Old,
        [Parameter(Mandatory = $true)][string]$New,
        [Parameter(Mandatory = $true)][string]$Description
    )

    if ($Text.Contains($New)) {
        Write-Host "Already applied: $Description"
        return $Text
    }

    if (-not $Text.Contains($Old)) {
        throw "Could not find expected text for: $Description"
    }

    Write-Host "Applying: $Description"
    return $Text.Replace($Old, $New)
}

$utf8NoBom = [System.Text.UTF8Encoding]::new($false)

$index = [System.IO.File]::ReadAllText($indexPath)
$index = Replace-Exact $index `
    '<h3 style="margin: 0 0 4px 0; font-size: 1.1rem; font-weight: 600; color: #111111;">Task Breakdown</h3>' `
    '<h3 style="margin: 0 0 4px 0; font-size: 1.1rem; font-weight: 600; color: #111111;">Tasks Breakdown</h3>' `
    'Task Breakdown -> Tasks Breakdown'

$index = Replace-Exact $index `
    'Flow from root tasks to the two direct contributions.' `
    'Topics are modelled from task names with ChatGPT 5.6 Sol' `
    'Sankey subtitle'

$index = Replace-Exact $index `
    "{ name: 'Unique Keys', value: 1033, itemStyle: { color: '#6b7280' } }" `
    "{ name: 'All Tasks', value: 1033, itemStyle: { color: '#6b7280' } }" `
    'Unique Keys -> All Tasks'

$index = Replace-Exact $index `
    "{ name: 'Commented, never assigned', value: 232, itemStyle: { color: '#a78bfa' } }" `
    "{ name: 'Commented, never assigned', value: 232, localX: 0.89, itemStyle: { color: '#a78bfa' } }" `
    'Move Commented, never assigned node left'

$index = Replace-Exact $index `
    "{ source: 'Unique Keys', target: 'Directly Assigned', value: 443 }" `
    "{ source: 'All Tasks', target: 'Directly Assigned', value: 443 }" `
    'Update first Sankey source'

$index = Replace-Exact $index `
    "{ source: 'Unique Keys', target: 'Indirect Participation', value: 575 }" `
    "{ source: 'All Tasks', target: 'Indirect Participation', value: 575 }" `
    'Update second Sankey source'

$i18n = [System.IO.File]::ReadAllText($i18nPath)
$i18n = Replace-Exact $i18n `
    '"Task Breakdown": "Разбор задач"' `
    '"Tasks Breakdown": "Разбор задач"' `
    'Update title translation key'

$i18n = Replace-Exact $i18n `
    '"Flow from root tasks to the two direct contributions.": "Поток от корневых задач к двум прямым вкладам."' `
    '"Topics are modelled from task names with ChatGPT 5.6 Sol": "Темы смоделированы по названиям задач с помощью ChatGPT 5.6 Sol"' `
    'Update subtitle translation'

$i18n = Replace-Exact $i18n `
    '"Unique Keys": "Уникальные ключи"' `
    '"All Tasks": "Все задачи"' `
    'Update root-node translation'

$i18n = Replace-Exact $i18n `
    '"Analytics, metric logic & modeling": "Аналитика, метрическая логика и моделирование"' `
    '"Analytics, metric logic & modeling": "Аналитика, логика метрик и моделирование"' `
    'Метрическая логика -> Логика метрик'

$i18n = Replace-Exact $i18n `
    '"Coordination & delivery management": "Координация и управление доставкой"' `
    '"Coordination & delivery management": "Координация и управление"' `
    'Управление доставкой -> управление'

Copy-Item -LiteralPath $indexPath -Destination "$indexPath.bak" -Force
Copy-Item -LiteralPath $i18nPath -Destination "$i18nPath.bak" -Force

[System.IO.File]::WriteAllText($indexPath, $index, $utf8NoBom)
[System.IO.File]::WriteAllText($i18nPath, $i18n, $utf8NoBom)

Write-Host ""
Write-Host "Done. Updated:" -ForegroundColor Green
Write-Host "  $indexPath"
Write-Host "  $i18nPath"
Write-Host "Backups:" -ForegroundColor DarkGray
Write-Host "  $indexPath.bak"
Write-Host "  $i18nPath.bak"
Write-Host ""
Write-Host "Review with: git -C `"$RepoPath`" diff -- index.html i18n.js"
